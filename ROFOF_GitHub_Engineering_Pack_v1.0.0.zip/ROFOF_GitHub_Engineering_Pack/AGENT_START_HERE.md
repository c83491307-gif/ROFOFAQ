# START HERE — ROFOF Engineering Agent

You are being given a product specification package and an engineering skill for the ROFOF project.

## Repository
https://github.com/c83491307-gif/ROFOFAQ

## Read these files first
1. `SKILL.md`
2. `engineering/TARGET_ARCHITECTURE.md`
3. `engineering/IMPLEMENTATION_ROADMAP.md`
4. `specifications/ROFOF_Android_Complete_Build_Package_v1.2.0.zip`

## Mandatory first task
Inspect the repository and all 28 specification documents before modifying source code. Produce a factual discovery report and requirement traceability matrix. Do not create a demo, do not replace the existing repository, and do not claim implementation is complete.

## Working mode
After discovery, proceed with implementation in small, verifiable stages. Preserve existing work. Use a feature branch and pull request if repository permissions allow. Run tests after meaningful changes. Report real commit SHAs, workflow URLs, and test outcomes.

## Safety
Never commit secrets. Never run real payments or external notifications in tests. Never merge or deploy to production without explicit authorization. If you have read-only repository permissions, stop before attempting writes and ask for write access or a user-performed upload.
