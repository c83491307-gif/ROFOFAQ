# ROFOF — ENTERPRISE FULL-STACK ENGINEERING SKILL
## Native Android · Deep Backend · Scalable Data · GitHub Engineering

**Project:** ROFOF  
**Repository:** https://github.com/c83491307-gif/ROFOFAQ  
**Specification package:** `specifications/ROFOF_Android_Complete_Build_Package_v1.2.0.zip`  
**Target:** A complete, production-oriented native Android and full-stack platform.

## 1. Mission

Transform ROFOF into a real, integrated software platform. This is not a UI-only exercise, a static prototype, or a demo.

The deliverable must include:
- A genuine native Android application.
- A deep backend with authoritative business rules.
- A relational database and migrations.
- Versioned APIs and authentication/authorization.
- Reliable background processing.
- Offline-capable local persistence and synchronization.
- Financial calculations and auditability.
- Reporting, exports, backup, and restore.
- Automated tests, CI, deployment assets, and documentation.

## 2. Source of truth and repository discovery

Before editing:
1. Inspect the complete repository, default branch, branches, commit history, existing files, CI workflows, and current build state.
2. Read every document in the supplied v1.2.0 specification archive. It contains 28 specification documents, plus supporting documentation and data resources.
3. Inspect the actual SQLite schema and all JSON, CSV, SQL, and image assets.
4. Map each requirement to a module, data entity, API, screen, and test.
5. Identify conflicts, ambiguity, missing decisions, and dependencies.
6. Preserve existing functionality and repository identity.

Do not replace an existing project with a new demo. Do not silently omit requirements. Do not invent business rules where the specifications are ambiguous; document the decision and its impact.

## 3. Recommended technology architecture

Choose technologies by responsibility, not by language count.

### Android
- Kotlin
- Android SDK
- Jetpack Compose and Material 3
- Coroutines and Flow
- Room / SQLite for local persistence
- DataStore for preferences
- WorkManager for durable background work
- Retrofit or Ktor Client
- Kotlin Serialization
- Hilt
- Navigation Compose

The Android client must be a real native application. Do not use a WebView as a substitute for the native product.

### Backend
- Kotlin
- Spring Boot
- Spring Security
- Spring Validation
- Spring Data / Hibernate where appropriate
- Flyway database migrations
- OpenAPI contracts
- Actuator and structured logging

The server is authoritative for financial rules, permissions, and persisted shared state.

### Data and infrastructure
- PostgreSQL as the authoritative relational database.
- Redis only for justified caching, rate limiting, coordination, or ephemeral state. Never make it the sole source of truth for financial transactions.
- Durable background job/queue processing for exports, reports, imports, reconciliation, and notifications.
- S3-compatible object storage for backups, attachments, and generated files.
- Docker and Docker Compose for reproducible local infrastructure.
- GitHub Actions for CI/CD.

### Optional web administration
Use TypeScript with React/Next.js only if an actual web administration interface is required by the specifications or approved scope.

Use SQL for schema, migrations, and query work. Use Python only for focused data migration, validation, or analytics tasks where it provides a clear benefit. Avoid unnecessary language proliferation.

## 4. Architecture strategy

Start with a modular monolith, not a premature collection of microservices. Separate domain modules and background workers cleanly so that independently scaling components can be extracted later when measurements justify it.

Suggested bounded contexts:
- Identity and access.
- Catalog and categories.
- Purchases and purchase items.
- Participants and allocations.
- Contributions and payments.
- Financial balances and reconciliation.
- Personal expenses (My Expenses).
- Reports and analytics.
- Backup, restore, and data portability.
- Notifications and background jobs.
- Audit and application settings.

## 5. Financial correctness

Treat financial data as high-integrity data.

- Use decimal-safe money types and explicit currency/precision policies.
- Never use binary floating-point arithmetic for monetary values.
- Keep expected obligations distinct from actual payments.
- Use atomic database transactions for multi-record financial operations.
- Use idempotency keys for retryable financial writes.
- Prevent duplicate payments and duplicate allocation.
- Record source references and audit history.
- Define concurrency controls and reconciliation rules.
- Do not silently overwrite financial records during sync.
- Do not double-count shared purchases in My Expenses.

My Expenses must remain an independent personal ledger. A shared purchase must not automatically become another personal expense merely because a participant paid for it. Model explicit relationships and allocation rules.

## 6. Database engineering

Use PostgreSQL for authoritative server-side data and Room for the Android local store.

Implement:
- Primary and foreign keys.
- Unique constraints.
- Appropriate indexes.
- Referential integrity.
- Versioned migrations.
- Transaction boundaries.
- Query-plan inspection.
- Pagination and filtering.
- Connection pooling.
- Data validation.
- Backup and restore verification.
- Archival policies that preserve historical transactions.

Do not claim scalability by creating oversized empty tables. Benchmark realistic synthetic workloads. Introduce partitioning, replicas, or sharding only when evidence and workload justify them.

## 7. API and backend requirements

Implement:
- Versioned REST endpoints.
- Explicit request/response DTOs.
- OpenAPI documentation.
- Authentication and resource-level authorization.
- Consistent error responses.
- Validation.
- Pagination, filtering, and sorting.
- Rate limiting.
- Idempotency for sensitive operations.
- Health and readiness endpoints.
- Structured logs and metrics.

Do not expose ORM entities directly as public API contracts. Never trust client-side financial calculations as authoritative.

## 8. Offline mode and synchronization

Use Room for local persistence and a durable pending-operation model.

Implement:
- Stable operation identifiers.
- Retry with bounded backoff.
- Idempotent server endpoints.
- Conflict detection.
- Explicit conflict policies by data type.
- Sync status visible to users.
- Safe recovery after process death.
- No silent overwrites of financial data.

Use WorkManager for durable Android background synchronization where appropriate.

## 9. Security

Implement:
- Secure authentication and password handling.
- Role- and resource-based authorization.
- TLS for network traffic.
- Input validation.
- SQL injection protection.
- Rate limiting.
- Secret management.
- Dependency vulnerability scanning.
- Audit trails.
- Sensitive-data redaction in logs.
- Secure backup access and restore validation.

Never commit API keys, passwords, production database credentials, signing keys, tokens, or private certificates. Use GitHub Secrets or a dedicated secret manager. Do not request unnecessary Android permissions.

## 10. Background processing and reliability

Use durable jobs for long-running work. Provide:
- Idempotent job handlers.
- Retry policies with backoff.
- Failure visibility.
- Dead-letter handling where appropriate.
- Job status and timestamps.
- Safe cancellation semantics.
- Observability for queue depth and processing latency.

Never silently discard failed jobs.

## 11. Android product requirements

Implement all specified modules as connected, working features:
- Dashboard.
- Purchases.
- Product and item catalog.
- Participants.
- Contributions and payments.
- Financial balances.
- My Expenses.
- Reports and analytics.
- Backup and restore.
- Settings.

Every visible control must perform its advertised action. Implement loading, empty, validation, success, failure, retry, and offline states. Support Arabic RTL and English LTR throughout the application.

## 12. Testing

Required test layers:
- Unit tests for financial rules and domain services.
- Database and migration tests.
- API tests for validation and authorization.
- Integration tests against a real test database.
- Android UI and navigation tests.
- Offline/synchronization tests.
- End-to-end financial workflows.
- Load tests using realistic synthetic workloads.
- Backup/restore integrity tests.
- Security and dependency checks.

Never report a test as passed unless it actually ran. Record command, environment, result, and relevant artifact/log.

## 13. GitHub engineering rules

- Inspect repository permissions and current branch before writing.
- Use a feature branch for implementation.
- Preserve unrelated work.
- Make small, traceable commits.
- Review diffs before committing.
- Run relevant checks after each meaningful change.
- Never force-push or overwrite unrelated work.
- Never merge or deploy to production without authorization.
- Never run real payment or external messaging operations during tests.
- If repository write permission is unavailable, stop before attempting writes and provide the exact required permission or user action.

## 14. CI/CD

Create GitHub Actions workflows for:
- Kotlin/Gradle validation.
- Android unit tests and lint.
- Backend compilation and tests.
- Database migration checks.
- API contract validation.
- Integration tests.
- Docker build.
- Dependency and secret scanning.
- Release APK/AAB generation when configured.

Separate pull-request verification from release and deployment workflows. Production deployment must require explicit environment protection and authorization.

## 15. Observability and operations

Provide:
- Structured logs.
- Health/readiness endpoints.
- API latency and error metrics.
- Database connection and query monitoring.
- Background job status.
- Synchronization failure metrics.
- Backup verification records.
- Operational runbooks.

Never log secrets or unnecessary personal financial details.

## 16. Execution phases

1. Repository and specification discovery.
2. Requirement traceability matrix.
3. Architecture and data model.
4. Build configuration and CI foundation.
5. Backend domain and API implementation.
6. Android native implementation.
7. Offline persistence and synchronization.
8. Reports, exports, backup, and restore.
9. Security, performance, and reliability hardening.
10. End-to-end verification and release preparation.

At every phase, report completed work, changed files, tests executed, failures, unresolved decisions, and next concrete tasks.

## 17. Definition of done

The project is not complete merely because the interface looks polished, the app compiles, or the backend starts.

Completion requires verified integration across Android, backend, APIs, database, financial rules, synchronization, and infrastructure. Critical workflows must pass tests. Data must persist. Backup and restore must be verified. Arabic and English must work. All known blockers must be documented.

**Final objective:** Deliver ROFOF as a reliable, maintainable, secure, native Android and full-stack financial management platform. Build the real system, not a demonstration of it.
