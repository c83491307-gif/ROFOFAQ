# ROFOF Security Baseline

- Never commit credentials, tokens, private keys, signing keys, or production secrets.
- Use GitHub Secrets or a dedicated secret manager for deployment configuration.
- Enforce authentication and resource-level authorization on every protected API.
- Validate all client input on the server.
- Use parameterized database access and safe ORM/query patterns.
- Use TLS for all non-local network traffic.
- Apply rate limits to authentication and sensitive endpoints.
- Redact personal and financial details from logs.
- Keep audit history for important financial changes.
- Test backup files before restore and require confirmation for destructive replacement.
- Do not use real payment gateways or external messaging in automated tests.
- Require explicit approval for production deployment.
