# ROFOF — Implementation Roadmap and Acceptance Matrix

## Phase 0 — Discovery (must precede code changes)

- [ ] Inspect default branch, branches, commits, permissions, and existing files.
- [ ] Inspect Gradle/JDK/Android configuration if present.
- [ ] Inspect every document in the v1.2.0 package.
- [ ] Inspect the SQLite schema and reference datasets.
- [ ] Produce a requirement-to-module traceability matrix.
- [ ] Identify conflicting, ambiguous, and missing business rules.
- [ ] Record current build/test baseline.
- [ ] Propose architecture and migration strategy without deleting existing code.

**Acceptance:** Discovery report identifies actual repository state, all specification sources, current build status, and unresolved decisions.

## Phase 1 — Engineering foundation

- [ ] Establish Android and backend build conventions.
- [ ] Establish module boundaries.
- [ ] Establish configuration and secret handling.
- [ ] Establish database migration tooling.
- [ ] Establish API error and DTO conventions.
- [ ] Establish CI workflows.
- [ ] Establish test fixtures and test database.

**Acceptance:** Reproducible local build and CI checks run against the actual repository.

## Phase 2 — Data and backend foundation

- [ ] Finalize normalized data model from specifications.
- [ ] Implement migrations and constraints.
- [ ] Implement authentication and authorization.
- [ ] Implement catalog and categories.
- [ ] Implement purchase and purchase-item domain.
- [ ] Implement participants and allocation rules.
- [ ] Implement payment and financial ledger rules.
- [ ] Implement My Expenses as a separate ledger.
- [ ] Implement audit and idempotency.

**Acceptance:** Domain and integration tests prove transactional correctness and access isolation.

## Phase 3 — Native Android

- [ ] Build application shell and navigation.
- [ ] Implement design system and localization.
- [ ] Implement dashboard from real data.
- [ ] Implement purchases and catalog.
- [ ] Implement participants, allocations, and payments.
- [ ] Implement My Expenses.
- [ ] Implement reports and settings.
- [ ] Implement loading, empty, error, and offline states.

**Acceptance:** Screens are connected to real repositories and backend contracts; UI tests cover critical flows.

## Phase 4 — Sync and data portability

- [ ] Implement Room persistence.
- [ ] Implement pending operation queue.
- [ ] Implement idempotent synchronization.
- [ ] Implement conflict handling.
- [ ] Implement export and import.
- [ ] Implement backup and restore verification.

**Acceptance:** Offline and reconnect tests prove no silent loss or duplicate financial writes.

## Phase 5 — Scale, security, and operations

- [ ] Add query and index analysis.
- [ ] Add load tests with documented workload.
- [ ] Add security and dependency scanning.
- [ ] Add logs, metrics, health checks, and job visibility.
- [ ] Add backup/restore runbook.
- [ ] Validate deployment configuration.

**Acceptance:** Results are measured and reported; no unsupported scale claims.

## Phase 6 — Release

- [ ] Build signed release artifact using user-provided secure signing configuration.
- [ ] Verify APK installation and launch.
- [ ] Verify API deployment separately from local development.
- [ ] Publish release notes and known limitations.
- [ ] Obtain explicit approval before production deployment.

## Required completion report

For each phase, report:
- Commit SHA and branch.
- Files added/changed.
- Tests and commands executed.
- Actual pass/fail counts.
- CI workflow URL and conclusion, if available.
- Remaining defects and unresolved decisions.
- Whether the result is local, committed, pushed, released, or deployed.

Never conflate these states.
