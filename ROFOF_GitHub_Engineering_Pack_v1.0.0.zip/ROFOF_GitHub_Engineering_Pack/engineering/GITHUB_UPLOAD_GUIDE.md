# GitHub Upload Instructions

1. Open https://github.com/c83491307-gif/ROFOFAQ
2. Select **Add file → Upload files**.
3. Extract this ZIP on your device or computer.
4. Upload the contents of the `ROFOF_GitHub_Engineering_Pack` folder into the repository root.
5. Commit with message: `Add ROFOF full-stack engineering specification pack`.
6. Keep the original `specifications/ROFOF_Android_Complete_Build_Package_v1.2.0.zip` intact.

Do not upload passwords, API keys, signing keys, tokens, or production database credentials.

After upload, give the AI coding agent repository access and ask it to follow `AGENT_START_HERE.md`.
