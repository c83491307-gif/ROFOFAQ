# ROFOF — Target Architecture

## Architecture decision summary

**Initial pattern:** Modular monolith + independently deployable background worker process where operationally justified.

**Why:** It gives strong domain boundaries and transactional consistency without introducing premature distributed-system failure modes. Extract services only when measured load, team ownership, or deployment isolation justifies it.

## Logical topology

```text
Native Android (Kotlin / Compose)
  ├── Presentation and navigation
  ├── Domain/use cases
  ├── Room local database
  ├── Pending operations / sync engine
  └── WorkManager
          │ HTTPS / versioned REST
          ▼
Backend API (Kotlin / Spring Boot)
  ├── Identity and authorization
  ├── Catalog and purchases
  ├── Participants and allocations
  ├── Payments and financial ledger
  ├── Personal expenses
  ├── Reports and exports
  ├── Audit and settings
  └── Job submission / status
          │
          ├── PostgreSQL (authoritative data)
          ├── Redis (optional cache/coordination)
          ├── Durable queue / worker execution
          └── S3-compatible object storage

GitHub
  ├── Source control and pull requests
  ├── GitHub Actions CI
  ├── Dependency/security scanning
  └── Release artifacts
```

## Core design rules

1. PostgreSQL is the server-side source of truth.
2. Room is a local persistence/cache layer, not a competing authority for shared financial state.
3. Financial writes are atomic and idempotent.
4. Money uses decimal-safe types and explicit currency rules.
5. API contracts use DTOs and versioning.
6. Offline writes are queued with stable operation IDs and reconciled by the server.
7. Redis is never the only durable record of a financial event.
8. Long-running exports and reports execute asynchronously.
9. Historical transactions preserve the values and labels that applied at transaction time.
10. Personal expenses and shared-purchase allocations remain distinct to prevent double counting.

## Initial domain boundaries

| Domain | Responsibilities |
|---|---|
| Identity | Users, sessions, roles, permissions |
| Catalog | Items, units, categories, subcategories |
| Purchases | Purchase headers, line items, totals |
| Participants | Participant profiles and membership |
| Allocations | Share rules and per-person obligations |
| Payments | Actual payment events and reversals |
| Ledger | Balances, reconciliation, auditability |
| My Expenses | Personal expense records and recurring items |
| Analytics | Daily/weekly/monthly/yearly summaries |
| Documents | Exports, attachments, backups |
| Jobs | Imports, exports, reports, reconciliation |
| Sync | Device operations, conflict detection, sync status |

## Scale strategy

Scale in this order:
1. Correct data model and query patterns.
2. Indexes and query-plan review.
3. Pagination and bounded response sizes.
4. Connection pooling and caching of safe read models.
5. Asynchronous processing for expensive work.
6. Read replicas or partitioning only after metrics show need.
7. Service extraction only when independent scaling or ownership is justified.

Do not promise an arbitrary number of users or records without workload assumptions and benchmarks.
