# ROFOF GitHub Engineering Pack

This pack consolidates the product specification and full-stack engineering instructions for the ROFOF project.

## Contents

- `SKILL.md` — complete engineering skill for an AI coding agent.
- `AGENT_START_HERE.md` — exact starting instructions.
- `engineering/TARGET_ARCHITECTURE.md` — architecture and technology boundaries.
- `engineering/IMPLEMENTATION_ROADMAP.md` — phased delivery and acceptance criteria.
- `specifications/ROFOF_Android_Complete_Build_Package_v1.2.0.zip` — original consolidated product specification package.

## Repository

https://github.com/c83491307-gif/ROFOFAQ

## Important

This is an engineering handoff/specification package. It is not an APK, and it does not claim that the Android application or backend has already been implemented.

The AI coding agent must inspect the existing repository and the complete specification archive before modifying code.

Recommended initial architecture:
- Android: Kotlin + Jetpack Compose + Room.
- Backend: Kotlin + Spring Boot.
- Main database: PostgreSQL.
- Optional cache/coordination: Redis.
- Background processing: durable jobs/workers.
- Infrastructure: Docker.
- CI/CD: GitHub Actions.

The initial architecture should be a modular monolith, with service extraction only when measured needs justify it.
